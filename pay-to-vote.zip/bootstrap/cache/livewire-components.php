<?php return array (
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'event.feed.card' => 'App\\Http\\Livewire\\Event\\Feed\\Card',
  'layouts.app.header' => 'App\\Http\\Livewire\\Layouts\\App\\Header',
  'layouts.app.sidebar' => 'App\\Http\\Livewire\\Layouts\\App\\Sidebar',
  'layouts.app.sidebar-right' => 'App\\Http\\Livewire\\Layouts\\App\\SidebarRight',
);