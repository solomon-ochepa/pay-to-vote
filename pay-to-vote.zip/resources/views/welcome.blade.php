<x-site-layout>
    <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
        {{ config('app.name') }}
    </div>
</x-site-layout>
