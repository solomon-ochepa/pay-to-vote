<x-app-layout>
    {{ $slot }}

    <livewire:layouts.app.sidebar-right />
</x-app-layout>
