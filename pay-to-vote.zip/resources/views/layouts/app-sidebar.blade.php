<x-app-layout>
    <livewire:layouts.app.sidebar />

    {{ $slot }}
</x-app-layout>
