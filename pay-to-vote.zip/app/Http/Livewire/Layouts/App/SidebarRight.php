<?php

namespace App\Http\Livewire\Layouts\App;

use Livewire\Component;

class SidebarRight extends Component
{
    public function render()
    {
        return view('livewire.layouts.app.sidebar-right');
    }
}
