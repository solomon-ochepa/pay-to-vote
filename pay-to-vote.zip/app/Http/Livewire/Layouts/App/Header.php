<?php

namespace App\Http\Livewire\Layouts\App;

use Livewire\Component;

class Header extends Component
{
    public function render()
    {
        return view('livewire.layouts.app.header');
    }
}
